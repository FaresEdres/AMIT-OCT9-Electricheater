

#ifndef ADC_INTERFACE_H_
#define ADC_INTERFACE_H_

void ADC_Inithlization(void);
u16 ADC_Start_Conversion(u8 Channel);
void ADC_Interrupt(void);
void ADC_Start_Conversion_Interrupt(u8 Channel);
u16 ADC_Reading(void);
void ADC_CallBackFunction(void (*Copy_PtrToFun)(void));

#endif /* ADC_INTERFACE_H_ */
