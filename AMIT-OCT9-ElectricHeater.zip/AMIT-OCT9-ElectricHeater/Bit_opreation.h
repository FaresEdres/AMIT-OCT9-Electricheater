#ifndef BIT_MATH_H_
#define BIT_MATH_H_

#define SET_BIT(Rig , Bit)      Rig|=(1<<Bit)
#define CLR_BIT(Rig , Bit)      Rig&=(~(1<<Bit))
#define TOGGLE_BIT(Rig , Bit)   Rig^=(1<<Bit)
#define GET_BIT(Rig , Bit)      ((Rig>>Bit)&1)

#endif
