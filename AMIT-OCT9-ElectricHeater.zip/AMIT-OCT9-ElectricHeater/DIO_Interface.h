

#ifndef DIO_INTERFACE_H_
#define DIO_INTERFACE_H_

#define PIN_INPUT  0
#define PIN_OUTPUT 1

#define PORT_INPUT   0
#define PORT_OUTPUT 255

#define DIO_PORTA  0
#define DIO_PORTB  1
#define DIO_PORTC  2
#define DIO_PORTD  3

#define PIN_HIGH   1
#define PIN_LOW    0

enum{
	DIO_PIN0,
	DIO_PIN1,
	DIO_PIN2,
	DIO_PIN3,
	DIO_PIN4,
	DIO_PIN5,
	DIO_PIN6,
	DIO_PIN7
}Pin_Number;

u8 DIO_Set_Pin_Direction(u8 Pin,u8 Port,u8 Direction);
u8 DIO_Set_Pin_Value(u8 Pin,u8 port,u8 Value);
u8 DIO_Get_Pin_Value(u8 Pin,u8 Port,u8*Value);
u8 DIO_Toggle_Pin_Value(u8 Pin,u8 Port);

void DIO_Set_Port_Direction(u8 Port,u8 Direction);
void DIO_Set_Port_Value(u8 Port, u8 port_Value);




#endif /* DIO_INTERFACE_H_ */
