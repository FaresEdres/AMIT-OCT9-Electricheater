

#include "Types.h"
#include "Bit_opreation.h"
#include "DIO_Interface.h"
#include "DIO_Private.h"

u8 DIO_Set_Pin_Direction(u8 Pin,u8 Port,u8 Direction)
{
	u8 Error_State=OK;
	if((Pin<8)&&(Pin>=0))
	{
		if(Direction==PIN_OUTPUT)
		{
			switch(Port)
			{
			case DIO_PORTA:
				SET_BIT(DDRA,Pin);
				break;
			case DIO_PORTB:
				SET_BIT(DDRB,Pin);
				break;
			case DIO_PORTC:
				SET_BIT(DDRC,Pin);
				break;
			case DIO_PORTD:
				SET_BIT(DDRD,Pin);
				break;
			default:
				Error_State=NOK;
				break;
			}

		}
		else if(Direction==PIN_INPUT)
		{
			switch(Port)
			{
			case DIO_PORTA:
				CLR_BIT(DDRA,Pin);
				break;
			case DIO_PORTB:
				CLR_BIT(DDRB,Pin);
				break;
			case DIO_PORTC:
				CLR_BIT(DDRC,Pin);
				break;
			case DIO_PORTD:
				CLR_BIT(DDRD,Pin);
				break;
			default:
				Error_State=NOK;
				break;
			}

		}
		else
		{
			Error_State=NOK;
		}
	}
	else
	{
		Error_State=NOK;
	}
	return Error_State;
}
u8 DIO_Set_Pin_Value(u8 Pin,u8 port,u8 Value)
{
	u8 Error_State=OK;
	if((Pin<8)&&(Pin>=0))
	{
		switch(port)
		{
		case DIO_PORTA:
			if(Value==PIN_HIGH)
			{
				SET_BIT(PORTA,Pin);
			}
			else if(Value==PIN_LOW)
			{
				CLR_BIT(PORTA,Pin);
			}
			else
			{
				Error_State=NOK;
			}
			break;
		case DIO_PORTB:
			if(Value==PIN_HIGH)
			{
				SET_BIT(PORTB,Pin);
			}
			else if(Value==PIN_LOW)
			{
				CLR_BIT(PORTB,Pin);
			}
			else
			{
				Error_State=NOK;
			}
			break;
		case DIO_PORTC:
			if(Value==PIN_HIGH)
			{
				SET_BIT(PORTC,Pin);
			}
			else if(Value==PIN_LOW)
			{
				CLR_BIT(PORTC,Pin);
			}
			else
			{
				Error_State=NOK;
			}
			break;
		case DIO_PORTD:
			if(Value==PIN_HIGH)
			{
				SET_BIT(PORTD,Pin);
			}
			else if(Value==PIN_LOW)
			{
				CLR_BIT(PORTD,Pin);
			}
			else
			{
				Error_State=NOK;
			}
			break;
		default:
			Error_State=NOK;
			break;
		}
	}
	else
	{
		Error_State=NOK;
	}
	return Error_State;
}

void DIO_Set_Port_Value(u8 Port, u8 port_Value)
{
	switch(Port)
	{
	case DIO_PORTA : PORTA =  port_Value ;break;
	case DIO_PORTB : PORTB =  port_Value ;break;
	case DIO_PORTC : PORTC =  port_Value ;break;
	case DIO_PORTD : PORTD =  port_Value ;break;
	}

}

void DIO_Set_Port_Direction(u8 Port,u8 Direction)
{
	switch(Port)
	{
	case DIO_PORTA : DDRA =  Direction ;break;
	case DIO_PORTB : DDRB =  Direction ;break;
	case DIO_PORTC : DDRC =  Direction ;break;
	case DIO_PORTD : DDRD =  Direction ;break;
	}

}

u8 DIO_Get_Pin_Value(u8 Pin,u8 Port,u8*Value)
{
	u8 ErrorState=OK;
	if(Pin<8)
	{
		switch(Port)
		{
		case DIO_PORTA :
			*Value=GET_BIT(PINA,Pin);
			break;
		case DIO_PORTB :
			*Value=GET_BIT(PINB,Pin);
			break;
		case DIO_PORTC :
			*Value=GET_BIT(PINC,Pin);
			break;
		case DIO_PORTD :
			*Value=GET_BIT(PIND,Pin);
			break;
		default:
			ErrorState=NOK;
			break;
		}
	}
	else
	{
		ErrorState=NOK;
	}
	return ErrorState;
}
