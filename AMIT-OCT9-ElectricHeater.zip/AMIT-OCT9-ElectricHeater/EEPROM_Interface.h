/*
 * EEPROM_Interface.h
 *
 *  Created on: Dec 1, 2021
 *      Author: Fares
 */

#ifndef EEPROM_INTERFACE_H_
#define EEPROM_INTERFACE_H_

void EEPROM_Inithlization(void);
u8 EEPROM_Write_Byte(u16 address,u8 Data);
u8 EEPROM_Read_Byte(u16 address,u8*Data);



#endif 
