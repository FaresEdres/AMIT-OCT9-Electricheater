/*
 * EEPROM_Prog.h
 *
 *  Created on: Dec 1, 2021
 *      Author: Fares
 */
#include "Bit_opreation.h"
#include "Types.h"
#include "I2C_config.h"
#include "I2C_Interface.h"

#include <util/delay.h>

void EEPROM_Inithlization(void)
{
    I2C_Inithilization(); 
}
u8 EEPROM_Write_Byte(u16 address , u8 Copy_u8Data)
{
	I2C_Start_Condition(); 
	if(I2C_Status_REG() != TW_START)
		return NOK;

	/*Write the slave address with write*/
	I2C_Write((u8)(0xA0|((address & 0x0700)>>7)));
	if (I2C_Status_REG() != TW_MT_SLA_W_ACK)
		return NOK;

	/*Send location address*/
	I2C_Write((u8)(address));
	if(I2C_Status_REG() != TW_MT_DATA_ACK)
		return NOK;

	/*Write byte to EEPROM*/
	I2C_Write(Copy_u8Data);
	if(I2C_Status_REG() != TW_MT_DATA_ACK)
		return NOK;

	I2C_Stop_Condition();
	return OK;
}

u8 EEPROM_Read_Byte(u16 address,u8*Data)
{
	I2C_Start_Condition(); 
	if(I2C_Status_REG() != TW_START)
		return NOK;

	/*Write the slave address with write*/
	I2C_Write((u8)(0xA0|((address & 0x0700)>>7)));
	if (I2C_Status_REG() != TW_MT_SLA_W_ACK)
		return NOK;

	/*Send location address*/
	I2C_Write((u8)(address));
	if(I2C_Status_REG() != TW_MT_DATA_ACK)
		return NOK;

	/*Send a repeated start*/
	I2C_Start_Condition();
	if(I2C_Status_REG() != TW_REP_START)
		return NOK;

	/*Write the device address with read*/
	I2C_Write((u8)( 0xA0 | ((address&0x0700)>>7) | 1 ));
	if(I2C_Status_REG() != TW_MT_SLA_R_ACK)
		return NOK;

	*Data=I2C_Read_Ack();
	if(I2C_Status_REG() != TW_MR_DATA_NACK)
		return NOK;

           I2C_Stop_Condition();
	return OK;
}
