/*
 * EXTI_Interface.h
 *
 *  Created on: Dec 1, 2021
 *      Author: Fares
 */

#ifndef EXTI_INTERFACE_H_
#define EXTI_INTERFACE_H_

void EXTI_INT_0_Inithlization(void);
void EXTI_INT_1_Inithlization(void);
void EXTI_INT_2_Inithlization(void);
void EXTI_Set_Sense_Control(u8 Control);

void EXTI_0_CallBackFunction(void (*PtrToFun)(void));
void EXTI_1_CallBackFunction(void (*PtrToFun)(void));
void EXTI_2_CallBackFunction(void (*PtrToFun)(void));


#endif 
