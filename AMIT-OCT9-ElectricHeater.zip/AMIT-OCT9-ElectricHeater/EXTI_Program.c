/*
 * I2C_config.h
 *
 *  Created on: Dec 1, 2021
 *      Author: Fares
 */



#include "Types.h"
#include "Bit_opreation.h"
#include "EXTI_Private.h"
#include "EXTI_Interface.h"

void (*INT_0_PTR)(void);
void (*INT_1_PTR)(void);
void (*INT_2_PTR)(void);




void EXTI_INT_0_Inithlization(void)
{
	/*select Sense Control (Falling edge)*/
	SET_BIT(MCUCR,1);
	CLR_BIT(MCUCR,0);
	/*Enable PIE INT0*/
	SET_BIT(GICR,6);
}
void EXTI_INT_1_Inithlization(void)
{
	/*select Sense Control (Rising edge)*/
	SET_BIT(MCUCR,2);
	SET_BIT(MCUCR,3);
	/*Enable PIE INT1*/
	SET_BIT(GICR,7);
}
void EXTI_INT_2_Inithlization(void)
{
	/*select Sense Control (Falling edge)*/
	CLR_BIT(MCUCR,6);
	/*Enable PIE INT2*/
	SET_BIT(GICR,5);
}

void EXTI_Set_Sense_Control(u8 Control)
{
	switch (Control)
	{
	case EXTI_FALLING_EDGE:
		SET_BIT(MCUCR,1);
		CLR_BIT(MCUCR,0);
		break;

	case EXTI_RISING_EDGE:
		SET_BIT(MCUCR,2);
		SET_BIT(MCUCR,3);
		break;

	case EXTI_ANY_LOGICAL_CHANGE:
		CLR_BIT(MCUCR,1);
		SET_BIT(MCUCR,3);
		break;

	case EXTI_LOW_LEVEL:
		CLR_BIT(MCUCR,1);
		CLR_BIT(MCUCR,0);
		break;
	default:
		break;

	}
}

void EXTI_0_CallBackFunction(void (*PtrToFun)(void))
{
	INT_0_PTR=PtrToFun;
}
void EXTI_1_CallBackFunction(void (*PtrToFun)(void))
{
	INT_1_PTR=PtrToFun;
}

void EXTI_2_CallBackFunction(void (*PtrToFun)(void))
{
	 INT_2_PTR=PtrToFun;
}

void __vector_1(void) __attribute__((signal));
void __vector_1(void)
{
	INT_0_PTR(); 
}
void __vector_2(void) __attribute__((signal));
void __vector_2(void)
{
	INT_1_PTR();
}
void __vector_3(void) __attribute__((signal));
void __vector_3(void)
{
	INT_2_PTR(); 
}
