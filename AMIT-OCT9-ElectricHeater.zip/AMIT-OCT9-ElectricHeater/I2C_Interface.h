/*
 * I2C_Interface.h
 *
 *  Created on: Dec 2, 2021
 *      Author: Fares
 */

#ifndef I2C_INTERFACE_H_
#define I2C_INTERFACE_H_


/* I2C Status Bits in the TWSR Register */
#define TW_START         0x08 // start has been sent
#define TW_REP_START     0x10 // repeated start
#define TW_MT_SLA_W_ACK  0x18 // Master transmit ( slave address + Write request ) to slave + Ack received from slave
#define TW_MT_SLA_R_ACK  0x40 // Master transmit ( slave address + Read request ) to slave + Ack received from slave
#define TW_MT_DATA_ACK   0x28 // Master transmit data and ACK has been received from Slave.
#define TW_MR_DATA_ACK   0x50 // Master received data and send ACK to slave
#define TW_MR_DATA_NACK  0x58 // Master received data but doesn't send ACK to slave

void I2C_Inithilization(void);
void I2C_Start_Condition(void);
void I2C_Stop_Condition(void);
void I2C_Write(u8 Data);
u8 I2C_Read_Ack(void);
u8 I2C_Read_Ack(void);
u8 I2C_Status_REG(void);


#endif 
