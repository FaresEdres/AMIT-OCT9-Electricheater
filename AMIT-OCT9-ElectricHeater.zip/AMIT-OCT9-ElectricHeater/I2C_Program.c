/*
 * I2C_Program.c
 *
 *  Created on: Dec 2, 2021
 *      Author: Fares
 */
#include "Types.h"
#include "Bit_opreation.h"
#include "I2C_Private.h"
#include "I2C_config.h"
#include "DIO_Interface.h"

#include <util/delay.h>


void I2C_Inithilization(void)
{
	TWBR = 0x0C;
	TWSR = 0x00;
	TWAR = 0b00000010;
	TWCR = (1<<TWEN);
}
void I2C_Start_Condition(void)
{
	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN);
	while(!GET_BIT(TWCR,TWINT));
}
void I2C_Stop_Condition(void)
{
	TWCR = (1<<TWINT) | (1<<TWSTO) | (1<<TWEN);
}
void I2C_Write(u8 Data)
{
	/*Put data on TWDR data register*/
	TWDR = Data;
	/* Clear the TWINT Flag before sending the data
	 * Enable the TWI
	 */
	TWCR = (1<<TWINT) | (1<<TWEN);
	/*Wait for the TWINT flag to set,
	 *which indicates that the data was sent successfully*/
	while(!GET_BIT(TWCR,TWINT));
}
u8 I2C_Read_Ack(void)
{
	/* Clear the TWINT flag
	 * Enable the Acknowledge bit
	 * Enable the TWI
	 */
	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA);
	/*wait for the TWINT flag set to indicate that recieving was successful*/
	while(!GET_BIT(TWCR,TWINT));
	/*Read data*/
	return TWDR;
}
u8 I2C_Status_REG(void)
{
	u8 Status;
	/*masking the eliminate first 3 bits and get last 5 bits*/
	Status = TWSR & 0xF8;
	return Status;
}

