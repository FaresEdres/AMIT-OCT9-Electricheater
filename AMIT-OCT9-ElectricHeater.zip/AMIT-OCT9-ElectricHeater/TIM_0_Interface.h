

#ifndef TIMER_INTERFACE_H_
#define TIMER_INTERFACE_H_

void TIM_0_inthlization(void);
void TIME_0_Enter_PrLoad(u8 Preload);
void TIM_0_Enter_CTC(u8 CTC);
void TIM_0_CallBackfunction(void(*Copy_voidP_CallBackFun)(void));
                                                                                                                                                                                                                                                                                                                                                                                                                                                     

#endif /* TIMER_INTERFACE_H_ */
