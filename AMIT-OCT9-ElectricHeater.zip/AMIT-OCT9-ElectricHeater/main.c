/*
 * main.c

 *    
 *  Created on: Dec, 1, 2021
 *  Author: Hady 
 */

#include "Types.h"
#include "Bit_opreation.h"

#include "DIO_Interface.h"
#include "DIO_Private.h"

#include "EEPROM_Interface.h"
#include "I2C_config.h"
#include "I2C_Interface.h"
#include "SEVEN_SEGMENT_Interface.h"


#include "ADC_Interface.h"
#include "EXTI_Interface.h"
#include "GIE_Interface.h"

#include "TIMER1_Config.h"
#include "TIMER1_Config.h"
#include "TIMER1_Interface.h"
#include "TIMER1_Interface.h"
#include "TIM_0_Interface.h"
#include "TIM_0_Conveg.h"
#include "TIM_0_Privet.h"

#include "Heater_Interface.h"
#include <util/delay.h>

u8 Temp1;
u8 SensorReading,SetTemperature;
int main (void)
{
	/*Set three buttons as Pull Up*/
	DIO_Set_Pin_Value(DIO_PIN2,DIO_PORTD,PIN_HIGH);
	DIO_Set_Pin_Value(DIO_PIN3,DIO_PORTD,PIN_HIGH);
	DIO_Set_Pin_Value(DIO_PIN2,DIO_PORTB,PIN_HIGH);

	/*Set EXT0 PIN as an interrupt for Down button*/
	DIO_Set_Pin_Direction(DIO_PIN2,DIO_PORTD,PIN_INPUT);
	/*Set EXT1 PIN as an interrupt for up button*/
	DIO_Set_Pin_Direction(DIO_PIN3,DIO_PORTD,PIN_INPUT);
	/*Set EXT2 PIN as an interrupt for Power button*/
	DIO_Set_Pin_Direction(DIO_PIN2,DIO_PORTB,PIN_INPUT);

	/*Set some test leds */
	DIO_Set_Pin_Direction(DIO_PIN5,DIO_PORTD,PIN_OUTPUT);
	DIO_Set_Pin_Direction(DIO_PIN7,DIO_PORTB,PIN_OUTPUT);

	/*Call back functions for Up and down buttons*/
	EXTI_0_CallBackFunction(&HEATER_voidButtonDown_EXTI0);
	EXTI_1_CallBackFunction(&HEATER_voidButtonUP_EXTI1);
	EXTI_2_CallBackFunction(&HEATER_voidPower_Button);

	/*Call back function timer 0*/
	TIM_0_CallBackfunction(&Timer0_Interrupt_Function);

	/*Call back function for ADC conversion for timer 1*/
	TIMER1_voidCallBackFunction(&HEATER_voidADC_Conversion);
	TIMER1_voidSetOCR1AValue(1560);
	ADC_CallBackFunction(&HEATER_voidADCSensorTempratureReading);

	/*Enable Global interrupts*/
	GIE_voidEnable();

	/*Enable external interrupts*/
	EXTI_INT_0_Inithlization();
	EXTI_INT_1_Inithlization();
	EXTI_INT_2_Inithlization();

	/*SEVEN SEGMENT initialization */
	SEVEN_SEGMENT_voidEnable();

	/*ADC initialization*/
	ADC_Inithlization();

	/*TIMER1 initialization*/
	TIMER1_voidInit();

	/*EEPROM init*/
	EEPROM_Inithlization();
	u16 AddressTemp = 0x0002;

	/*Set pin direction for heater and cooler*/
	DIO_Set_Pin_Direction(DIO_PIN2 , DIO_PORTC , PIN_OUTPUT);
	DIO_Set_Pin_Direction(DIO_PIN4 , DIO_PORTC , PIN_OUTPUT);


	Heater_voidHeatingElementOff();
	Heater_voidCoolingElementOff();
	SEVEN_SEGMENT_voidOFF();
	Heater_voidSensorOFF();
	Heater_voidLedOFF();

	/*read the EEPROM Value*/
	EEPROM_Read_Byte(AddressTemp,&Temp1);
	SetGlobalTemp(Temp1);

	/*By default the temp displayed is the actual one*/
	OperationMode(TEMPACTUAL);

	while(1)
	{
		if(SEVEN_SEGMENT_GetBlinkingStatus()==ENABLED)
		{
			/*If the blinking is on then we display the set temperature*/
			OperationMode(TEMPSET);
		}
		else
		{
			if(Temp1 != GlobalTempRead())
			{
				Temp1 = GlobalTempRead();
				EEPROM_Write_Byte(AddressTemp,Temp1);
			}
			OperationMode(TEMPACTUAL);
		}

		SensorReading = ActTempRead();
		SetTemperature = GlobalTempRead();
		HEATER_u8CompareTemperature(SensorReading,SetTemperature);
	}
	return 0;
}



